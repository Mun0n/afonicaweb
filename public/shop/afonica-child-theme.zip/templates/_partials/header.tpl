{extends file='parent:_partials/header.tpl'}

{block name='stylesheets' append}
  <link rel="stylesheet" href="https://afonicanaranjo.com/shop/afonica-live-patch.css" type="text/css" media="all">
{/block}

{block name='header_banner'}
  <div class="afonica-top-bar"><a href="https://www.afonicanaranjo.com">← Afónica Naranjo</a></div>
  {$smarty.block.parent}
{/block}
