{extends file='parent:_partials/header.tpl'}
{block name='header_banner'}
  <div class="afonica-top-bar"><a href="https://www.afonicanaranjo.com">← Afónica Naranjo</a></div>
  {$smarty.block.parent}
{/block}
